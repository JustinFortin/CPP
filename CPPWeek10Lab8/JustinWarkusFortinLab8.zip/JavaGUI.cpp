﻿#include "JavaGUI.h"
#include <iostream>



using namespace std;

JNIEXPORT jdouble JNICALL Java_JavaGUI_calculateSTDDev(JNIEnv* env, jobject thisObj, jintArray inJNIArray) {
    jdouble mean = Java_JavaGUI_calculateMean(env, thisObj, inJNIArray);
    jint* array = env->GetIntArrayElements(inJNIArray, NULL);
    if (NULL == array) return 0;
    jsize length = env->GetArrayLength(inJNIArray);
    jdouble var = 0.0;
    for (int i = 0; i < length; ++i)
        var += pow((double)array[i] - mean, 2);
    env->ReleaseIntArrayElements(inJNIArray, array, 0);
    jdouble std = sqrt(var / length);
    return std;
}

JNIEXPORT jdouble JNICALL Java_JavaGUI_calculateMean(JNIEnv* env, jobject thisObj, jintArray inJNIArray) {
    jint* array = env->GetIntArrayElements(inJNIArray, NULL);
    if (NULL == array) return 0;
    jsize length = env->GetArrayLength(inJNIArray);
    jint sum = 0;
    int i;
    for (i = 0; i < length; i++) {
        sum += array[i];
    }
    jdouble average = (jdouble)sum / length;
    env->ReleaseIntArrayElements(inJNIArray, array, 0); 

    return average;
}
